import React from 'react'
import '../css/ProductCard.css'
import { Link } from 'react-router-dom'

const ProductCard = ({id,title,image,price}) => {
  return (
    <div className="card">
        <img src={image} alt={id} className='card-image'/>
        <h3>{title}</h3>
        <p>${price}</p>
        <Link to = {`/product/${id}`}>
        <button className='btn'>
            View Details
        </button>
         </Link>
        </div>
  )
}

export default ProductCard