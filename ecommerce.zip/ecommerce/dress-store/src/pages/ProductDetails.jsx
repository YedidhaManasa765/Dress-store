import React, {useState,useEffect} from 'react'
import {useParams,useNavigate} from 'react-router-dom'
import axios from 'axios'
import {ThemeContext} from '../context/ThemeContext'
import {useContext} from 'react'
import '../css/ProductDetails.css'

const ProductDetails = () => {
    const {theme} = useContext(ThemeContext);
    const {id} = useParams();
    const navigate = useNavigate();
    const [product,setProduct] = useState(null);
    const [loading,setLoading] = useState(true);
    const [error,setError] = useState('');
    //fetching product
    useEffect(()=>{
        axios.get(`https://fakestoreapi.com/products/${id}`)
        .then(res =>{
            setProduct(res.data);
            setLoading(false);
        })
        .catch(err=>{
            setError(err.message);
            setLoading(false);
        })
    },[id]);
    if(loading) return <p>Loading...</p>
    if(error) return <p>{error}</p>
  return (
    <>
        <div className='product-container' style={{background:theme === 'dark'?'#181818':'#fefefe'}}>
            <img src={product.image} alt={product.title} className='image' />
            <div className="details">
                <h2>{product.title}</h2>
                <p><strong>$ {product.price}</strong></p>
                <p>{product.description}</p>
                <p>Category: {product.category}</p>
                <p>Rating: ⭐⭐⭐⭐⭐</p>
                <button onClick={()=>navigate(-1)} className='backBtn'>
                    Go Back
                </button>
                <button className='addBtn'>
             
                    Add to cart
                </button>
            </div>
        </div>
    </>
  )
}

export default ProductDetails