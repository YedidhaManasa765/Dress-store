import React, { useState,useEffect } from 'react'
import axios from 'axios'
import ProductCard from '../components/ProductCard';
import AddProduct from './Addproduct';
import {Link} from 'react-router-dom'
import '../css/Home.css';

const Home = () => {
    const[products,setProducts] = useState([]);
    const[loading, setLoading]= useState(true);
    const[error,setError]= useState('');
    const[categories,setCategories] = useState([]);
    const[selectedCategory,setSelectedCategory]=useState('all');
    const[searchTerm,setSearchTerm]=useState("");
    const[sortOption,setSortOption]=useState('default');

    //useEffect for fetching categories
    useEffect(()=>{
        axios.get('https://fakestoreapi.com/products/categories')
        .then(res=>setCategories(res.data))
        .catch(err=>console.log('error occured while fetching categories'));
    },[])
    //normal fetching
    useEffect(()=>{
        setLoading(true);
            const url = selectedCategory === 'all'?'https://fakestoreapi.com/products':`https://fakestoreapi.com/products/category/${selectedCategory}`;
            axios.get(url)
            .then(res=>{
                setProducts(res.data);
                setLoading(false);
            })
            .catch(err=>{
                setError(error.message);
                setLoading(false);
        })
    },[selectedCategory]);
    //handle search
    const filteredProducts = products.filter(product=>product.title.toLowerCase().includes(searchTerm.toLowerCase()));
    //handle sorting
    const sortedProducts = [...filteredProducts].sort((a,b)=>{
        if(sortOption==='lowToHigh') return a.price - b.price;
        if(sortOption==='HighToLow') return b.price - a.price;
        
    })

    if(loading) return <p>Loading...</p>
    if(error) return <p>Error:{error}</p>
  return (
    <>
    <div className="controls">
        <select onChange={(e)=>setSelectedCategory(e.target.value)} value={setSelectedCategory}>
            <option value='all'>All Categories</option>
            {categories.map((cat)=>{
                return <option key={cat} value={cat}>{cat}</option>
            })}
        </select>
        {/* Search input  */}
        <input type='text' value={searchTerm} placeholder='Search products' onChange={(e)=>{setSearchTerm(e.target.value)}}/>
        {/* sorting */}
        <select onChange={(e)=>{setSortOption(e.target.value)}}value={sortOption}>
            <option value="default">Sort by</option>
            <option value="lowToHigh">Price:Low to High</option>
            <option value="HighToLow">Price:High to Low</option>
        </select>
    <div className='container'>
        {sortedProducts.length===0?(
            <p>products not found</p>
        ):(
            sortedProducts.map((product)=>{
                return <ProductCard key={product.id} 
                id={product.id} 
                title={product.title} 
                image={product.image} 
                price={product.price} />


                
            })
        )}
       
    </div>
    </div>
    </>
  )
}
export default Home;